# New dataset football > 104 val ball
https://universe.roboflow.com/shai-1c9ud/new-dataset-football

Provided by a Roboflow user
License: CC BY 4.0

